/**
 * 
 */
/**
 * 
 */
module task_12 {
	    requires java.sql; // Required for JDBC connection
	    requires java.desktop; // Required for Swing and AWT



}