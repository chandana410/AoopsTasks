/**
 * 
 */
/**
 * 
 */
module task_10 {
}