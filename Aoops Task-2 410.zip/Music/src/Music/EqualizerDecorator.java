package Music;

public class EqualizerDecorator {

}
