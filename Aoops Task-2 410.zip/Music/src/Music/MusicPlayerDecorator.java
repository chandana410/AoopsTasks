package Music;

public abstract class MusicPlayerDecorator {

}
