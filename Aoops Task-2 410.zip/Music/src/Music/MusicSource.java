package Music;

// Adapter Pattern: Common Interface for Music Sources
interface MusicSource {
    void play();
}
